import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const Home: React.FC = () => {
  return (
    <div className="max-w-4xl bg-white rounded-lg shadow-md p-6 md:p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-primary-700 mb-4">
          Estudo de Casos Interativos com Árvore Decisória Diagnóstica
        </h2>
        <h3 className="text-xl font-semibold text-neutral-700 mb-3">
          Infecções Bacterianas Comuns no Nordeste do Brasil
        </h3>

        <div className="bg-neutral-50 p-4 rounded-md border-l-4 border-primary-500 mb-6">
          <p className="mb-3">
            A presente seção tem como objetivo fortalecer a capacidade do leitor de aplicar os conceitos fundamentais de bacteriologia discutidos por meio de estudos de caso clínicos interativos. Estes casos foram cuidadosamente elaborados para promover o raciocínio clínico, a integração dos conhecimentos e a tomada de decisão baseada em evidências, com foco nas infecções prevalentes no contexto da saúde pública do Nordeste brasileiro.
          </p>
          <p>
            Cada estudo simula uma situação clínica realista, em que o leitor será conduzido por uma árvore decisória progressiva, com perguntas sequenciais e múltiplas opções de conduta. As respostas selecionadas conduzem a diferentes caminhos diagnósticos e terapêuticos, com comentários técnicos imediatos que validam, corrigem ou reorientam as escolhas feitas.
          </p>
        </div>

        <div className="mb-6">
          <h4 className="text-lg font-medium text-primary-600 mb-2">
            Além de seu caráter instrucional, esta abordagem tem por finalidade desenvolver habilidades práticas em:
          </h4>
          <ul className="list-disc pl-6 space-y-1">
            <li>Pensamento clínico estruturado e integração de conceitos bacteriológicos;</li>
            <li>Aplicação do conhecimento teórico à resolução de problemas médicos complexos;</li>
            <li>Tomada de decisão fundamentada em evidência biomédica;</li>
            <li>Reconhecimento de erros comuns e armadilhas clínicas no diagnóstico e manejo de infecções bacterianas;</li>
            <li>Compreensão da relevância da bacteriologia para a saúde pública.</li>
          </ul>
        </div>

        <div className="bg-yellow-50 p-4 rounded-md border-l-4 border-yellow-400 mb-6">
          <p className="font-medium text-yellow-800">IMPORTANTE:</p>
          <p className="text-yellow-800">
            Os casos aqui apresentados são inteiramente simulados para fins didáticos. Não representam pacientes reais nem devem ser utilizados como substitutos de orientação clínica especializada. O conteúdo segue diretrizes técnicas atuais à época de publicação, podendo evoluir com o avanço da ciência biomédica.
          </p>
        </div>
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-medium text-primary-600 mb-3">
          Como utilizar esta seção – Passo a Passo
        </h4>
        <ol className="list-decimal pl-6 space-y-3">
          <li>
            <p className="font-medium">Leia atentamente a apresentação do caso clínico.</p>
            <p className="text-sm text-neutral-600">
              Observe dados como idade, sintomas, tempo de evolução, contexto socioambiental e achados clínicos. Faça uma leitura analítica, identificando os elementos-chave que ajudarão na formulação das hipóteses diagnósticas.
            </p>
          </li>
          <li>
            <p className="font-medium">Formule hipóteses iniciais antes de avançar.</p>
            <p className="text-sm text-neutral-600">
              Antes de ler as opções de resposta da primeira pergunta, tente mentalmente elaborar hipóteses prováveis com base na epidemiologia, fisiopatologia e nos temas de bacteriologia relevantes.
            </p>
          </li>
          <li>
            <p className="font-medium">Siga a sequência de perguntas e etapas indicadas.</p>
            <p className="text-sm text-neutral-600">
              Escolha a alternativa que considerar mais adequada. Você será direcionado para uma etapa específica, conforme a árvore decisória. Continue seguindo o caminho indicado em cada etapa até a conclusão do caso.
            </p>
          </li>
          <li>
            <p className="font-medium">
              Leia com atenção os comentários técnicos após cada escolha.
            </p>
            <p className="text-sm text-neutral-600">
              Cada decisão é acompanhada de uma explicação que justifica o acerto, corrige desvios ou alerta para condutas inadequadas. Estes comentários são fundamentais para consolidar o aprendizado e ampliar o discernimento clínico-bacteriológico.
            </p>
          </li>
          <li>
            <p className="font-medium">Em caso de erro, retorne e reavalie.</p>
            <p className="text-sm text-neutral-600">
              Caso sua escolha leve a uma conduta inadequada ou incompleta, você será orientado a retornar e reconsiderar suas decisões. Este retorno faz parte do processo de aprendizagem ativa e crítica.
            </p>
          </li>
          <li>
            <p className="font-medium">Chegue à conclusão do caso.</p>
            <p className="text-sm text-neutral-600">
              Ao final, será apresentada uma análise técnica integrativa, com destaque para os conceitos centrais de bacteriologia aplicados ao caso. Essa conclusão resume o raciocínio clínico ideal e reforça os principais eixos temáticos.
            </p>
          </li>
          <li>
            <p className="font-medium">Faça conexões com o conteúdo teórico.</p>
            <p className="text-sm text-neutral-600">
              Após concluir o caso, recomenda-se retornar às seções teóricas sobre os microrganismos e mecanismos discutidos, promovendo um ciclo contínuo de reforço e consolidação do conhecimento.
            </p>
          </li>
        </ol>

        <p className="mt-4 text-neutral-700">
          Esta metodologia interativa está alinhada com as melhores práticas de ensino biomédico contemporâneo, estimulando a autonomia intelectual e a capacidade de julgamento clínico criterioso.
        </p>
        <p className="mt-2 font-medium text-primary-600">
          Boa leitura e bom estudo!
        </p>
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/case/1">
          <div>
            <Button 
              className="px-6 py-3 bg-primary-600 text-white font-medium rounded-md hover:bg-primary-700 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
            >
              Iniciar Caso Clínico 1
            </Button>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Home;
