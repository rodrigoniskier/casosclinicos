import React, { useEffect } from "react";
import { useRoute, useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cases } from "@/data/case1";

const CasePresentation: React.FC = () => {
  const [match, params] = useRoute<{ caseId: string }>("/case/:caseId");
  const [_, setLocation] = useLocation();

  useEffect(() => {
    if (!match) {
      setLocation("/");
      return;
    }

    const caseId = parseInt(params.caseId);
    if (isNaN(caseId) || !cases[caseId - 1]) {
      setLocation("/");
    }
  }, [match, params, setLocation]);

  if (!match) return null;

  const caseId = parseInt(params.caseId);
  const currentCase = cases[caseId - 1];

  if (!currentCase) return null;

  return (
    <div className="max-w-4xl bg-white rounded-lg shadow-md p-6 md:p-8">
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <div className="h-8 w-8 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold mr-3">
            {caseId}
          </div>
          <h2 className="text-2xl font-bold text-primary-700">
            Caso Clínico {caseId}
          </h2>
        </div>

        <Card className="bg-neutral-50 p-5 rounded-lg border border-neutral-200">
          <h3 className="text-lg font-semibold text-neutral-800 mb-3">Apresentação do Caso:</h3>
          <div className="space-y-3">
            {currentCase.presentation.map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>
        </Card>
      </div>

      <div className="mb-4">
        <h3 className="text-xl font-semibold text-primary-700 mb-3">
          {currentCase.initialQuestion.text}
        </h3>
        <p className="mb-4">{currentCase.initialQuestion.description}</p>

        <div className="space-y-4 mt-6">
          {currentCase.initialQuestion.options.map((option, index) => (
            <Link
              key={index}
              href={`/response/${caseId}/${currentCase.initialQuestion.id}/${option.id}`}
            >
              <div className="decision-card block p-4 border border-neutral-300 rounded-lg hover:border-primary-400 hover:bg-primary-50 hover:shadow-md transition-transform transform hover:-translate-y-0.5 cursor-pointer">
                <div className="flex">
                  <div className="flex-shrink-0 mr-3">
                    <div className="h-6 w-6 rounded-full border-2 border-primary-600 flex items-center justify-center text-sm font-medium text-primary-600">
                      {option.id}
                    </div>
                  </div>
                  <div>
                    <p>{option.text}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CasePresentation;
