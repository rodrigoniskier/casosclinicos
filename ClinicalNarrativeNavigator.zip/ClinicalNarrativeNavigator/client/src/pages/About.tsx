import React from "react";

const About: React.FC = () => {
  return (
    <div className="max-w-4xl bg-white rounded-lg shadow-md p-6 md:p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-primary-700 mb-4">
          Sobre o Projeto
        </h2>
        
        <div className="prose max-w-none">
          <h3 className="text-xl font-semibold text-primary-600 mb-3">
            Rodrigo Niskier – Produtor de Aplicativo Educacional em Saúde: Mecanismos de Agressão, Patológicos e de Defesa
          </h3>
          
          <p>
            Rodrigo Niskier é biomédico formado pela Universidade Federal de Pernambuco (2003), com especialização em Biologia Molecular (2004), mestrado em Genética (2007). Ao longo de mais de 17 anos de docência no ensino superior, acumulou experiência nas disciplinas de Microbiologia, Imunologia, Parasitologia e Patologia ministradas em cursos da área da saúde, com atuação principal nos cursos de Biomedicina e Medicina.
          </p>
          
          <p>
            Atualmente, além de suas atribuições como professor e pesquisador, o professor Rodrigo atua como desenvolvedor e produtor de soluções tecnológicas aplicadas ao ensino na área de saúde. Seu mais recente projeto é a idealização e estruturação de um aplicativo interativo para estudo de casos clínicos em Mecanismos de Agressão e Defesa, voltado à formação de estudantes de saúde no raciocínio clínico e fisiopatológico.
          </p>
          
          <p>
            A ferramenta está sendo desenvolvida na plataforma Replit, explorando os recursos de programação web para criar narrativas interativas baseadas em árvore decisória, com suporte a múltiplos caminhos clínicos, feedbacks automáticos e explicações embasadas em literatura científica. O aplicativo visa integrar conhecimento de imunopatologia, microbiologia, resposta inflamatória, necrose, apoptose, mecanismos moleculares de lesão celular, regeneração tecidual e cicatrização, de forma contextualizada em casos clínicos reais e simulados.
          </p>
        </div>
        
        <div className="mt-6 p-4 bg-primary-50 border-l-4 border-primary-500 rounded-md">
          <p className="text-primary-800 font-medium">
            Idealizado e desenvolvido pelo Prof. Rodrigo Niskier
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;