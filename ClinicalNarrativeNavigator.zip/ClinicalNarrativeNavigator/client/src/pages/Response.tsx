import React, { useEffect, useState } from "react";
import { useRoute, useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  ChevronRight, 
  Home,
  ArrowLeft
} from "lucide-react";
import { cases } from "@/data/case1";
import { CaseStep, Option } from "@/types/cases";

const Response: React.FC = () => {
  const [match, params] = useRoute<{ caseId: string; stepId: string; optionId: string }>("/response/:caseId/:stepId/:optionId");
  const [_, setLocation] = useLocation();
  const [currentCase, setCurrentCase] = useState<any>(null);
  const [response, setResponse] = useState<any>(null);
  const [nextQuestion, setNextQuestion] = useState<CaseStep | null>(null);

  useEffect(() => {
    if (!match) {
      setLocation("/");
      return;
    }

    const caseId = parseInt(params.caseId);
    const stepId = params.stepId;
    const optionId = params.optionId;

    if (isNaN(caseId) || !cases[caseId - 1]) {
      setLocation("/");
      return;
    }

    const caseData = cases[caseId - 1];
    setCurrentCase(caseData);

    // Find the current step
    let step: CaseStep | undefined;
    if (stepId === caseData.initialQuestion.id) {
      step = caseData.initialQuestion;
    } else {
      step = caseData.steps.find(s => s.id === stepId);
    }

    if (!step) {
      setLocation(`/case/${caseId}`);
      return;
    }

    // Find the selected option
    const option = step.options.find(o => o.id === optionId);
    if (!option) {
      setLocation(`/case/${caseId}`);
      return;
    }

    // Find the response based on the option
    const resp = caseData.responses.find(r => r.id === option.responseId);
    if (!resp) {
      setLocation(`/case/${caseId}`);
      return;
    }

    setResponse(resp);

    // If this response has a next question, find it
    if (resp.nextQuestionId) {
      const nextQ = caseData.steps.find(s => s.id === resp.nextQuestionId);
      setNextQuestion(nextQ || null);
    } else {
      setNextQuestion(null);
    }

  }, [match, params, setLocation]);

  if (!match || !currentCase || !response) return null;

  const caseId = parseInt(params.caseId);
  const stepId = params.stepId;
  const optionId = params.optionId;

  const getStatusIcon = () => {
    if (response.isCorrect) {
      return <CheckCircle className="text-green-600 text-xl mr-3" />;
    } else if (response.isIncorrect) {
      return <XCircle className="text-red-600 text-xl mr-3" />;
    } else {
      return <AlertCircle className="text-yellow-600 text-xl mr-3" />;
    }
  };

  const getStatusClass = () => {
    if (response.isCorrect) {
      return "bg-green-50 border-green-500";
    } else if (response.isIncorrect) {
      return "bg-red-50 border-red-500";
    } else {
      return "bg-yellow-50 border-yellow-400";
    }
  };

  const getStatusTitle = () => {
    if (response.isCorrect) {
      return "Conduta Correta";
    } else if (response.isIncorrect) {
      return "Conduta Inadequada";
    } else {
      return response.title || "Resultado";
    }
  };

  return (
    <div className="max-w-4xl bg-white rounded-lg shadow-md p-6 md:p-8">
      <div className="mb-4">
        <nav className="flex mb-5" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            <li className="inline-flex items-center">
              <Link href={`/case/${caseId}`}>
                <div className="inline-flex items-center text-sm font-medium text-neutral-700 hover:text-primary-600 cursor-pointer">
                  <Home className="w-4 h-4 mr-2" />
                  Caso {caseId}
                </div>
              </Link>
            </li>
            <li>
              <div className="flex items-center">
                <ChevronRight className="text-neutral-400 mx-2 text-sm" />
                <span className="text-sm font-medium text-neutral-500">
                  {stepId === currentCase.initialQuestion.id 
                    ? `Pergunta ${stepId.replace('q', '')}`
                    : `Etapa ${stepId}`} - Opção {optionId}
                </span>
              </div>
            </li>
          </ol>
        </nav>

        <div className={`p-4 rounded-md border-l-4 mb-6 ${getStatusClass()}`}>
          <div className="flex">
            <div className="flex-shrink-0">
              {getStatusIcon()}
            </div>
            <div>
              <h4 className={`text-lg font-medium ${response.isCorrect ? 'text-green-800' : response.isIncorrect ? 'text-red-800' : 'text-yellow-800'}`}>
                Etapa {response.id}: {getStatusTitle()}
              </h4>
              <p className={response.isCorrect ? 'text-green-700' : response.isIncorrect ? 'text-red-700' : 'text-yellow-700'}>
                {response.subtitle}
              </p>
            </div>
          </div>
        </div>

        {response.content && (
          <Card className="bg-neutral-50 p-4 rounded-lg border border-neutral-200 mb-6">
            <div className="space-y-3">
              {response.content.map((paragraph: string, idx: number) => (
                <p key={idx} className="mb-3">{paragraph}</p>
              ))}
            </div>
          </Card>
        )}

        <div className="mb-6">
          <h4 className="text-lg font-semibold text-primary-700 mb-2">
            Comentário Técnico:
          </h4>
          <div className="bg-blue-50 p-4 rounded-md">
            <div className="space-y-3">
              {response.technicalComment.map((paragraph: string, idx: number) => (
                <p key={idx} className={idx < response.technicalComment.length - 1 ? "mb-3" : ""}>
                  {paragraph}
                </p>
              ))}
            </div>

            {response.bacteriologicalReview && (
              <div className="bg-white p-3 rounded border border-blue-200 my-3">
                <h5 className="font-medium text-primary-700 mb-1">
                  {response.bacteriologicalReview.title}
                </h5>
                <p>{response.bacteriologicalReview.content}</p>
              </div>
            )}

            {response.reflectionPoint && (
              <p className="mt-3">{response.reflectionPoint}</p>
            )}
          </div>
        </div>

        {response.reflectionBox && (
          <div className="bg-yellow-50 p-4 rounded-md border-l-4 border-yellow-400 mb-6">
            <h4 className="font-medium text-yellow-800 mb-1">
              {response.reflectionBox.title}
            </h4>
            <p className="text-yellow-800">{response.reflectionBox.content}</p>
          </div>
        )}

        {nextQuestion && (
          <div className="mt-8">
            <h3 className="text-xl font-semibold text-primary-700 mb-3">
              {nextQuestion.text}
            </h3>
            <p className="mb-4">{nextQuestion.description}</p>

            <div className="space-y-4 mt-6">
              {nextQuestion.options.map((option, index) => (
                <Link
                  key={index}
                  href={`/response/${caseId}/${nextQuestion.id}/${option.id}`}
                >
                  <div className="decision-card block p-4 border border-neutral-300 rounded-lg hover:border-primary-400 hover:bg-primary-50 hover:shadow-md transition-transform transform hover:-translate-y-0.5 cursor-pointer">
                    <div className="flex">
                      <div className="flex-shrink-0 mr-3">
                        <div className="h-6 w-6 rounded-full border-2 border-primary-600 flex items-center justify-center text-sm font-medium text-primary-600">
                          {option.id}
                        </div>
                      </div>
                      <div>
                        <p>{option.text}</p>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {response.isIncorrect && (
          <div className="flex justify-center mt-6 space-x-4">
            <Link href={`/case/${caseId}`}>
              <div>
                <Button className="flex items-center px-6 py-3 bg-primary-600 text-white font-medium rounded-md hover:bg-primary-700 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retornar para a pergunta
                </Button>
              </div>
            </Link>
          </div>
        )}

        {!nextQuestion && !response.isIncorrect && (
          <div className="flex justify-center mt-6">
            <Link href={`/case/${caseId}`}>
              <div>
                <Button className="flex items-center px-6 py-3 bg-primary-600 text-white font-medium rounded-md hover:bg-primary-700 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar para o caso
                </Button>
              </div>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default Response;
