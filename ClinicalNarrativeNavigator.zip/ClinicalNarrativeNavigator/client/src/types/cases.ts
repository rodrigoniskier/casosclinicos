export interface Option {
  id: string;
  text: string;
  responseId: string;
}

export interface CaseStep {
  id: string;
  text: string;
  description: string;
  options: Option[];
}

export interface BacteriologicalReview {
  title: string;
  content: string;
}

export interface ReflectionBox {
  title: string;
  content: string;
}

export interface Response {
  id: string;
  title?: string;
  subtitle: string;
  content?: string[];
  technicalComment: string[];
  bacteriologicalReview?: BacteriologicalReview;
  reflectionPoint?: string;
  reflectionBox?: ReflectionBox;
  isCorrect?: boolean;
  isIncorrect?: boolean;
  nextQuestionId?: string;
}

export interface Case {
  id: number;
  title: string;
  presentation: string[];
  initialQuestion: CaseStep;
  steps: CaseStep[];
  responses: Response[];
}
