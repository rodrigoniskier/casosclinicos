import { Case } from "@/types/cases";

export const cases: Case[] = [
  {
    id: 1,
    title: "Caso Clínico 1",
    presentation: [
      "J.S.L., 2 anos, sexo masculino, residente em uma área periférica de João Pessoa (PB), com saneamento básico descrito pela mãe como \"muito ruim, com esgoto a céu aberto na rua\".",
      "A mãe, Sra. Maria, traz a criança à Unidade Básica de Saúde (UBS) visivelmente aflita.",
      "Ela relata que há aproximadamente 24 horas J.S.L. iniciou um quadro de diarreia muito líquida, de cor amarelada, sem muco ou sangue visível, com cerca de 8 evacuações ao dia. Informa também que o filho vomitou 3 vezes nas últimas horas e apresentou uma febre baixa (37,8°C aferida em casa com termômetro axilar).",
      "A criança está prostrada e com choro fraco, segundo a mãe."
    ],
    initialQuestion: {
      id: "q1",
      text: "Pergunta 1:",
      description: "Com base na história clínica inicial de J.S.L. (2 anos, diarreia aquosa intensa, vômitos, prostração) e no contexto socioambiental desfavorável (Nordeste do Brasil, saneamento precário), qual é a sua principal preocupação imediata e a conduta inicial mais adequada?",
      options: [
        { 
          id: "A", 
          text: "Avaliar imediatamente o estado de hidratação da criança, enquanto se colhe mais detalhes sobre as características da diarreia, ingesta hídrica recente e débito urinário.", 
          responseId: "1A" 
        },
        { 
          id: "B", 
          text: "Presumir uma infecção bacteriana grave devido ao saneamento precário e prescrever um antibiótico oral de amplo espectro imediatamente, orientando a mãe a retornar se não houver melhora em 48 horas.", 
          responseId: "1B" 
        },
        { 
          id: "C", 
          text: "Tranquilizar a mãe, informando que provavelmente se trata de uma virose comum da infância que se resolverá espontaneamente, e recomendar hidratação oral em casa com líquidos caseiros e observação.", 
          responseId: "1C" 
        }
      ]
    },
    steps: [
      {
        id: "q2",
        text: "Pergunta 2:",
        description: "Considerando o quadro clínico de J.S.L. (diarreia aquosa profusa, descrita como \"água de arroz\", vômitos e desidratação significativa) e o contexto epidemiológico (criança de 2 anos, área com saneamento básico precário no Nordeste), qual dos seguintes agentes etiológicos bacterianos se torna o principal suspeito para este quadro clássico, especialmente se houver relatos de outros casos semelhantes na comunidade?",
        options: [
          { 
            id: "A", 
            text: "Escherichia coli enterotoxigênica (ETEC), conhecida por causar diarreia aquosa através da produção das toxinas LT e ST.", 
            responseId: "2A" 
          },
          { 
            id: "B", 
            text: "Vibrio cholerae (sorogrupos O1 ou O139), agente etiológico da cólera, caracterizada por diarreia aquosa volumosa e rápida desidratação.", 
            responseId: "2B" 
          },
          { 
            id: "C", 
            text: "Shigella dysenteriae, que tipicamente causa disenteria (diarreia com sangue, muco e pus), febre alta e dor abdominal intensa.", 
            responseId: "2C" 
          }
        ]
      },
      {
        id: "q3A",
        text: "Pergunta 3A:",
        description: "Considerando a ETEC (ou outras enterobactérias como causa de diarreia aquosa) e a necessidade de manejo da desidratação em J.S.L., qual é a conduta terapêutica fundamental e imediata, independentemente da confirmação etiológica específica neste momento?",
        options: [
          { 
            id: "A", 
            text: "Iniciar imediatamente antibioticoterapia com Ciprofloxacina, pois ETEC pode ser resistente a outros antimicrobianos.", 
            responseId: "3A1" 
          },
          {
            id: "B",
            text: "Iniciar hidratação endovenosa imediata para correção da desidratação, com soro fisiológico e/ou soluções eletrolíticas de acordo com o plano C da OMS para desidratação grave.",
            responseId: "3A2"
          },
          {
            id: "C",
            text: "Administrar sais de reidratação oral (SRO) em pequenas quantidades frequentes, usando uma seringa para contornar os vômitos, e reavaliar a cada 30 minutos.",
            responseId: "3A3"
          }
        ]
      },
      {
        id: "q3B",
        text: "Pergunta 3B:",
        description: "Diante da suspeita de cólera em uma criança com desidratação significativa como J.S.L., quais são as duas condutas imediatas e prioritárias que devem ser implementadas concomitantemente?",
        options: [
          { 
            id: "A", 
            text: "1) Iniciar antibioticoterapia específica para Vibrio cholerae como primeira prioridade; 2) Notificar autoridades sanitárias para investigação epidemiológica e bloqueio de surto.", 
            responseId: "3B1" 
          },
          {
            id: "B",
            text: "1) Iniciar hidratação venosa imediata para correção da desidratação; 2) Colher amostras de fezes para confirmação laboratorial antes de qualquer intervenção terapêutica.",
            responseId: "3B2"
          },
          {
            id: "C",
            text: "1) Iniciar hidratação venosa imediata para correção da desidratação; 2) Notificar autoridades sanitárias para investigação epidemiológica e medidas de contenção.",
            responseId: "3B3"
          }
        ]
      },
      {
        id: "q4",
        text: "Pergunta 4:",
        description: "Independentemente de a causa ser ETEC ou Vibrio cholerae, J.S.L. está recebendo reidratação. Para fins de investigação laboratorial e saúde pública (especialmente se for cólera), qual a abordagem diagnóstica bacteriológica mais informativa a partir de uma amostra de fezes diarreicas?",
        options: [
          { 
            id: "A", 
            text: "Apenas realizar um teste rápido para rotavírus, pois é a causa mais comum de diarreia em crianças, e se negativo, não investigar mais.", 
            responseId: "4A" 
          },
          {
            id: "B",
            text: "Solicitar coprocultura em meios de rotina (ex: MacConkey, Ágar Sangue) e, dada a suspeita clínica de \"água de arroz\", solicitar especificamente cultura em meio TCBS (Tiossulfato-Citrato-Bile-Sacarose) e, se disponível, teste rápido para detecção de antígeno de V. cholerae nas fezes.",
            responseId: "4B"
          },
          {
            id: "C",
            text: "Realizar apenas coloração de Gram do esfregaço fecal direto para visualizar vibriões curvos, o que seria suficiente para confirmar cólera.",
            responseId: "4C"
          }
        ]
      },
      {
        id: "q5",
        text: "Pergunta 5:",
        description: "Do ponto de vista da saúde pública no Nordeste do Brasil, e considerando a prevenção de surtos de diarreias bacterianas graves transmitidas pela via fecal-oral, como as causadas por Vibrio cholerae e ETEC, qual das seguintes medidas é a mais crítica e de maior impacto a longo prazo?",
        options: [
          { 
            id: "A", 
            text: "Implementação de campanhas anuais de vacinação em massa contra cólera e ETEC para toda a população da região.", 
            responseId: "5A" 
          },
          {
            id: "B",
            text: "Distribuição profilática em massa de antibióticos para comunidades em áreas de risco durante os períodos de maior incidência de diarreia.",
            responseId: "5B"
          },
          {
            id: "C",
            text: "Investimento contínuo e abrangente em infraestrutura de saneamento básico (água potável tratada e encanada, coleta e tratamento adequados de esgoto) e educação em saúde sobre higiene pessoal e alimentar.",
            responseId: "5C"
          }
        ]
      }
    ],
    responses: [
      {
        id: "1A",
        subtitle: "Você optou por avaliar imediatamente o estado de hidratação e colher mais detalhes.",
        isCorrect: true,
        content: [
          "Ao examinar J.S.L., você observa: mucosas orais secas, olhos fundos, turgor cutâneo diminuído (prega cutânea retorna lentamente), fontanela anterior (\"moleira\") visivelmente deprimida. A frequência cardíaca está elevada (FC: 145 bpm) e os pulsos periféricos são rápidos e finos.",
          "Durante a anamnese complementar, a Sra. Maria refere que a diarreia é \"como água de arroz, sai muita água mesmo a cada vez\", e que a criança não urina há aproximadamente 8 horas. Também informa que não conseguiu fazer com que a criança bebesse água ou outros líquidos nas últimas horas porque \"tudo o que dou, ele vomita\"."
        ],
        technicalComment: [
          "Excelente decisão! A avaliação imediata e detalhada do estado de hidratação é crucial em qualquer criança com diarreia aguda, especialmente com os sinais de alerta apresentados. Os achados do exame físico (mucosas secas, olhos fundos, turgor diminuído, fontanela deprimida, taquicardia) confirmam um quadro de desidratação, que parece ser no mínimo moderada, tendendo a grave.",
          "A descrição da diarreia como \"água de arroz\" e a oligúria (débito urinário ausente há 8 horas) são sinais adicionais preocupantes que reforçam a gravidade do quadro e a necessidade de intervenção imediata. A dificuldade em manter a hidratação oral devido aos vômitos persistentes é outro fator que pode justificar uma abordagem mais intensiva.",
          "Este primeiro passo de avaliação minuciosa foi fundamental para determinar a severidade do quadro e permitirá planejar a terapêutica adequada, além de fornecer pistas importantes para o diagnóstico etiológico."
        ],
        reflectionBox: {
          title: "Ponto de Reflexão Bacteriológica:",
          content: "A característica \"água de arroz\" das fezes é classicamente associada a qual patógeno bacteriano específico, especialmente em contextos de saneamento deficiente e potencial epidêmico?"
        },
        nextQuestionId: "q2"
      },
      {
        id: "1B",
        subtitle: "Você optou por prescrever um antibiótico oral de amplo espectro imediatamente.",
        isIncorrect: true,
        technicalComment: [
          "Esta conduta não é a mais adequada neste momento inicial. Embora o contexto de saneamento precário possa aumentar o risco de infecções bacterianas, a prioridade absoluta em uma criança com diarreia aguda e sinais de prostração é a avaliação e manejo da desidratação.",
          "Muitas diarreias agudas, mesmo em contextos desfavoráveis, são de etiologia viral ou causadas por toxinas bacterianas onde o antibiótico não é a primeira linha de tratamento ou pode não ter impacto significativo na fase inicial.",
          "A prescrição empírica de antibiótico sem avaliação clínica detalhada pode levar a várias consequências indesejáveis:",
          "• Omissão da avaliação e tratamento da desidratação, que frequentemente é a causa mais imediata de morbidade e mortalidade;",
          "• Tratamento antimicrobiano inadequado caso o agente etiológico não seja sensível ao antibiótico escolhido;",
          "• Contribuição para a resistência antimicrobiana;",
          "• Efeitos adversos desnecessários.",
          "O uso de antibióticos em diarreia aguda só deve ser considerado após avaliação clínica completa, estabilização hídrica e de acordo com critérios específicos (sintomas disentéricos, febre alta, suspeita fundamentada de patógenos específicos, etc.)."
        ]
      },
      {
        id: "1C",
        subtitle: "Você optou por tranquilizar a mãe e recomendar apenas hidratação oral em casa.",
        isIncorrect: true,
        technicalComment: [
          "Embora seja verdade que muitas diarreias agudas na infância são virais e autolimitadas, os sinais de alerta apresentados por J.S.L. (prostração, choro fraco, 8 episódios de diarreia em 24h, vômitos) não permitem uma conduta expectante sem uma avaliação clínica presencial e detalhada do estado de hidratação.",
          "A prostração, em particular, pode ser um sinal de desidratação significativa ou de uma doença mais grave. Minimizar esses sinais pode levar a atrasos no tratamento adequado, com potenciais consequências sérias, especialmente em uma criança pequena (2 anos) que pode descompensar rapidamente.",
          "A hidratação oral é, de fato, a base do tratamento para a maioria dos casos de diarreia aguda, mas deve ser recomendada após a avaliação do grau de desidratação e da capacidade da criança em aceitar líquidos. Casos de desidratação moderada a grave podem necessitar de hidratação supervisionada ou até mesmo parenteral.",
          "Além disso, o contexto epidemiológico e socioambiental (saneamento precário) aumenta o risco de infecções potencialmente mais graves, incluindo aquelas que podem beneficiar-se de terapia antimicrobiana específica."
        ]
      },
      {
        id: "2A",
        title: "Etapa 2A",
        subtitle: "Você suspeitou de Escherichia coli enterotoxigênica (ETEC).",
        technicalComment: [
          "E. coli enterotoxigênica (ETEC) é, de fato, uma causa muito importante e frequente de diarreia aquosa em crianças e adultos em regiões com saneamento deficiente, como no Nordeste do Brasil. Ela produz enterotoxinas (termolábil - LT e/ou termoestável - ST) que atuam nos enterócitos, causando secreção intensa de fluidos e eletrólitos, resultando em diarreia líquida. É uma hipótese diagnóstica diferencial relevante para diarreia aquosa."
        ],
        bacteriologicalReview: {
          title: "Revisão Bacteriológica da ETEC:",
          content: "É um bacilo Gram-negativo pertencente à família Enterobacteriaceae. A identificação de ETEC requer a detecção de seus fatores de virulência (toxinas), pois morfologicamente e em cultura de rotina, ela é indistinguível de E. coli comensal."
        },
        reflectionPoint: "Ponto de Reflexão: Embora ETEC cause diarreia aquosa, a descrição \"água de arroz\" é um sinal de alerta mais específico para outro patógeno. Contudo, a ETEC continua sendo um diagnóstico diferencial importante para diarreias aquosas em geral nesse contexto.",
        nextQuestionId: "q3A"
      },
      {
        id: "2B",
        title: "Etapa 2B",
        subtitle: "Você suspeitou de Vibrio cholerae.",
        isCorrect: true,
        technicalComment: [
          "Correto! Esta é a principal suspeita. A descrição clássica de fezes como \"água de arroz\" (diarreia acinzentada, turva, com flocos de muco, sem odor fétido ou com leve odor de peixe), associada à diarreia aquosa de início súbito, profusa, indolor, que leva rapidamente à desidratação grave, vômitos e cãibras (devido à perda de eletrólitos), em um contexto de saneamento precário, é altamente sugestiva de cólera, causada por cepas toxigênicas do Vibrio cholerae."
        ],
        bacteriologicalReview: {
          title: "Revisão Bacteriológica do Vibrio cholerae:",
          content: "É um bacilo (vibrião) Gram-negativo, curvo ou em forma de vírgula, anaeróbio facultativo, altamente móvel devido a um flagelo polar. Sua principal virulência reside na produção da toxina colérica (CTX), que causa uma hipersecreção de água e eletrólitos no lúmen intestinal."
        },
        reflectionPoint: "Ponto de Reflexão: Dada a gravidade potencial da cólera e o risco epidêmico, quais são as duas ações prioritárias e imediatas no manejo de um caso suspeito como o de J.S.L.?",
        nextQuestionId: "q3B"
      },
      {
        id: "2C",
        title: "Etapa 2C",
        subtitle: "Você suspeitou de Shigella dysenteriae.",
        isIncorrect: true,
        technicalComment: [
          "Esta hipótese é menos provável para o quadro clínico descrito. Shigella spp., especialmente S. dysenteriae (que produz a toxina Shiga), é um agente clássico de disenteria bacilar. A disenteria se caracteriza por diarreia com pouco volume, mas com presença de sangue, muco e pus nas fezes, acompanhada frequentemente de febre alta, cólicas abdominais intensas e tenesmo (sensação de evacuação incompleta).",
          "A diarreia de J.S.L. foi descrita como aquosa, abundante (\"muita água mesmo a cada vez\") e \"como água de arroz\", sem sangue ou muco, o que não é consistente com o padrão clínico típico da shiguelose.",
          "Além disso, na shigelose, o comprometimento do estado geral e a desidratação ocorrem geralmente devido ao estado toxêmico, febre alta e inapetência, mais do que pela perda volumosa de líquidos nas fezes, como parece ser o caso de J.S.L."
        ]
      },
      {
        id: "3A1",
        subtitle: "Você optou por iniciar antibioticoterapia com Ciprofloxacina.",
        isIncorrect: true,
        content: [
          "Você prescreve Ciprofloxacina para J.S.L., priorizando o tratamento antimicrobiano antes da reposição de fluidos. Após algumas horas, a desidratação da criança piora significativamente, com sinais de colapso circulatório. Há necessidade de intervenções emergenciais para estabilização."
        ],
        technicalComment: [
          "Esta não é a conduta prioritária no manejo da diarreia aquosa com desidratação. Embora os antibióticos possam ter papel no tratamento de certos casos de diarreia de origem bacteriana (incluindo ETEC), a primeira e mais urgente intervenção deve ser sempre a correção da desidratação.",
          "A desidratação grave é a principal causa de morte nas diarreias infecciosas, e pode evoluir para choque hipovolêmico, insuficiência renal aguda e óbito em poucas horas, especialmente em crianças pequenas.",
          "O Ministério da Saúde e a Organização Mundial da Saúde são enfáticos: a correção da desidratação é a medida salvadora de vidas e deve preceder qualquer outra intervenção terapêutica.",
          "Além disso, a Ciprofloxacina, embora seja efetiva contra muitas enterobactérias, não é a primeira escolha pediátrica devido aos potenciais efeitos adversos sobre cartilagens em desenvolvimento, sendo reservada para situações específicas."
        ]
      },
      {
        id: "3A2",
        subtitle: "Você optou por iniciar hidratação endovenosa imediata seguindo o plano C da OMS.",
        isCorrect: true,
        content: [
          "Você inicia imediatamente a hidratação endovenosa de J.S.L. seguindo o Plano C da OMS para desidratação grave: uma fase inicial rápida com soro fisiológico (30 ml/kg na primeira hora, seguida de 70 ml/kg nas 5 horas seguintes), monitorando frequentemente os sinais vitais, débito urinário e nível de consciência.",
          "Após 2 horas de hidratação, J.S.L. apresenta melhora significativa: está mais alerta, com fontanela menos deprimida, mucosas menos secas, e já produziu pequeno volume de urina. Os vômitos diminuíram, permitindo iniciar oferta oral de pequenos volumes frequentes de SRO na segunda fase do tratamento."
        ],
        technicalComment: [
          "Excelente decisão! A hidratação endovenosa imediata é, de fato, a intervenção prioritária e potencialmente salvadora de vidas em casos de desidratação moderada a grave, especialmente quando há impossibilidade de hidratação oral efetiva devido aos vômitos.",
          "O Plano C da OMS é a abordagem recomendada para desidratação grave ou para casos moderados com intolerância oral ou comprometimento do estado geral. Ele envolve reposição hídrica vigorosa, com monitoramento frequente.",
          "Esta abordagem trata o problema fisiopatológico central e mais imediatamente ameaçador à vida nas diarreias aquosas intensas: a hipovolemia e os distúrbios hidroeletrolíticos. A correção da desidratação é a base do tratamento e deve preceder considerações sobre terapia antimicrobiana específica, que é adjuvante em alguns casos.",
          "A rápida melhora observada em J.S.L. confirma a adequação da conduta e permite transição gradual para hidratação oral assim que possível, o que é sempre desejável."
        ],
        nextQuestionId: "q4"
      },
      {
        id: "3A3",
        subtitle: "Você optou por administrar sais de reidratação oral (SRO) usando seringa.",
        isIncorrect: true,
        content: [
          "Você tenta administrar SRO em pequenos volumes com seringa, contornando os vômitos. Apesar de seus esforços, J.S.L. continua vomitando a maior parte do líquido oferecido. Nas horas seguintes, seu estado geral piora, com aprofundamento da desidratação, estado mental mais comprometido e sinais preocupantes de choque hipovolêmico."
        ],
        technicalComment: [
          "Embora a hidratação oral com SRO seja o tratamento de escolha para a maioria dos casos de diarreia com desidratação leve a moderada, e a técnica de oferecer pequenos volumes frequentes seja correta, esta abordagem não é adequada no contexto apresentado por J.S.L.:",
          "• Desidratação que parece ser moderada a grave pelos sinais físicos descritos;",
          "• Vômitos persistentes que impedem a retenção adequada dos líquidos orais;",
          "• Estado geral comprometido com prostração.",
          "Nas diretrizes da OMS e do Ministério da Saúde, a presença desses fatores indica necessidade de hidratação endovenosa (Plano C). Insistir apenas na via oral em tais circunstâncias pode resultar em:  inadequada correção da desidratação, progressão para desidratação grave e choque, e atraso em uma intervenção mais efetiva.",
          "A hidratação oral poderá ser instituída assim que houver melhora dos vômitos e do estado geral, como parte da segunda fase do tratamento."
        ]
      },
      {
        id: "3B1",
        subtitle: "Você optou por iniciar antibioticoterapia específica para Vibrio cholerae como primeira prioridade e notificar autoridades sanitárias.",
        isIncorrect: true,
        content: [
          "Você prioriza iniciar antibioticoterapia para Vibrio cholerae e aciona as autoridades sanitárias. Enquanto aguarda a medicação ser preparada, percebe que J.S.L. está cada vez mais letárgico, com extremidades frias e pulso periférico quase impalpável - sinais de choque hipovolêmico em evolução."
        ],
        technicalComment: [
          "Embora a notificação às autoridades sanitárias seja uma medida correta e necessária diante da suspeita de cólera, e a antibioticoterapia tenha seu lugar no manejo (reduzindo a duração e volume da diarreia), estas não são as intervenções mais urgentes e prioritárias.",
          "A cólera mata principalmente pela rápida e intensa desidratação que causa. A mortalidade sem tratamento pode chegar a 50-70%, mas cai para menos de 1% com hidratação adequada. O tratamento da desidratação é, portanto, a medida que salva vidas e deve sempre preceder qualquer terapia antimicrobiana.",
          "A toxina colérica já produzida continua agindo mesmo após o início do antibiótico, e a perda hidroeletrolítica persistirá por algum tempo. O paciente pode evoluir para óbito por choque hipovolêmico mesmo que o agente etiológico esteja sendo combatido adequadamente pelo antimicrobiano."
        ]
      },
      {
        id: "3B2",
        subtitle: "Você optou por iniciar hidratação venosa e coletar amostras para confirmação laboratorial.",
        isIncorrect: true,
        content: [
          "Você inicia hidratação venosa de J.S.L. e, concomitantemente, organiza a coleta de amostras fecais para confirmação laboratorial. A criança responde bem à hidratação, mas não há medidas para conter a potencial disseminação do agente no ambiente comunitário."
        ],
        technicalComment: [
          "A hidratação venosa imediata é, certamente, a conduta prioritária e correta. No entanto, em um caso suspeito de cólera, a notificação imediata às autoridades sanitárias é tão urgente quanto o manejo clínico do paciente, devido ao potencial epidêmico e impacto em saúde pública da doença.",
          "A coleta de amostras para confirmação diagnóstica, embora importante, não é tão urgente quanto a notificação, pois:",
          "• A notificação permite o início imediato de investigação epidemiológica e medidas de contenção que podem evitar um surto;",
          "• A cólera é uma doença de notificação compulsória imediata (em 24h) na maioria dos países, incluindo o Brasil, mesmo diante apenas de suspeita;",
          "• Enquanto a confirmação laboratorial pode levar dias, medidas preventivas na comunidade podem ser iniciadas em poucas horas após a notificação.",
          "A coleta de amostras é compatível e deve ser realizada paralelamente à hidratação e notificação, mas não deve substituir esta última como conduta prioritária."
        ]
      },
      {
        id: "3B3",
        subtitle: "Você optou por iniciar hidratação venosa imediata e notificar autoridades sanitárias.",
        isCorrect: true,
        content: [
          "Você inicia imediatamente a hidratação endovenosa de J.S.L. conforme protocolo para desidratação grave. Simultaneamente, aciona a Vigilância Epidemiológica para notificar o caso suspeito de cólera. Uma equipe de investigação é mobilizada rapidamente para avaliar a situação na comunidade, coletar amostras e implementar medidas preventivas.",
          "J.S.L. responde positivamente à hidratação, e após estabilização, inicia-se antibioticoterapia adjuvante (doxiciclina de dose única, conforme protocolo). A criança recupera-se completamente em poucos dias."
        ],
        technicalComment: [
          "Esta é a conduta ideal! A hidratação endovenosa imediata aborda a ameaça mais imediata à vida do paciente - a desidratação grave. Ao mesmo tempo, a notificação às autoridades sanitárias cumpre a responsabilidade de saúde pública e permite intervenções precoces na comunidade para prevenir a disseminação.",
          "A cólera é uma emergência dupla - individual e coletiva - e ambas as dimensões exigem ações imediatas e simultâneas. O manejo correto inclui:",
          "• Hidratação agressiva (endovenosa nos casos graves) - reduzindo mortalidade de até 50% para menos de 1%;",
          "• Notificação imediata - permitindo medidas de bloqueio, investigação de fonte, educação comunitária e prevenção de novos casos;",
          "• Antibioticoterapia como adjuvante (após início da hidratação) - reduzindo volume e duração da diarreia;",
          "• Precauções entéricas - evitando contaminação no ambiente hospitalar.",
          "Esta abordagem integrada é fundamental para o controle de doenças com potencial epidêmico como a cólera."
        ],
        nextQuestionId: "q4"
      },
      {
        id: "4A",
        subtitle: "Você optou por realizar apenas teste rápido para rotavírus.",
        isIncorrect: true,
        content: [
          "Você solicita apenas o teste rápido para rotavírus nas fezes de J.S.L. O resultado é negativo, e você considera encerrada a investigação etiológica. Dias depois, é notificado que novos casos semelhantes surgiram na mesma comunidade, com um padrão sugestivo de transmissão hídrica."
        ],
        technicalComment: [
          "Conduta Incompleta: Rotavírus é uma causa importante de diarreia aquosa em crianças, e o teste rápido é útil. No entanto, o quadro clínico de J.S.L., especialmente a descrição de \"água de arroz\" e a gravidade da desidratação em um contexto de saneamento precário, levanta uma forte suspeita de cólera, uma doença bacteriana de notificação compulsória e com alto potencial epidêmico.",
          "Limitar a investigação ao rotavírus seria perder a oportunidade de diagnosticar e controlar precocemente um potencial surto de doença de impacto coletivo significativo. A abordagem diagnóstica deve ser ampliada para incluir métodos direcionados para agentes bacterianos, especialmente Vibrio cholerae, considerando o contexto clínico e epidemiológico.",
          "Uma investigação laboratorial insuficiente pode resultar em subnotificação de doenças de interesse em saúde pública e atrasar medidas de controle necessárias para conter a propagação."
        ],
        nextQuestionId: "q4"
      },
      {
        id: "4B",
        subtitle: "Você optou por solicitar coprocultura em meios de rotina, meio TCBS específico para Vibrio, e teste rápido para antígeno de V. cholerae.",
        isCorrect: true,
        content: [
          "Você solicita a coleta adequada de fezes para os exames indicados. O laboratório de microbiologia reporta, em 24 horas, resultado positivo no teste rápido para antígeno de V. cholerae. Simultaneamente, inicia-se cultura em meio TCBS, que após 18-24 horas revela colônias amarelas sugestivas de V. cholerae. A confirmação com testes bioquímicos e sorológicos identifica V. cholerae O1, biotipo El Tor."
        ],
        technicalComment: [
          "Excelente! Esta é a abordagem laboratorial mais completa e adequada.",
          "Coprocultura em meios de rotina: Permite o isolamento de outras enterobactérias patogênicas, como ETEC (embora a diferenciação de cepas comensais exija testes de virulência), Salmonella, Shigella.",
          "Meio TCBS: É um meio seletivo e diferencial para o isolamento de Vibrio spp. V. cholerae tipicamente produz colônias amarelas neste meio devido à fermentação da sacarose.",
          "Teste rápido para antígeno de V. cholerae: Pode fornecer um resultado presuntivo em minutos a partir da amostra fecal, o que é crucial para o manejo rápido do paciente e para as ações de saúde pública em caso de surto. A confirmação final da cólera envolve o isolamento de V. cholerae toxigênico (O1 ou O139) na cultura."
        ],
        reflectionPoint: "Qual a importância da identificação do sorogrupo e da biotipagem do V. cholerae para a epidemiologia?",
        nextQuestionId: "q5"
      },
      {
        id: "4C",
        subtitle: "Você optou por realizar apenas coloração de Gram do esfregaço fecal.",
        isIncorrect: true,
        content: [
          "Você solicita apenas a coloração de Gram do esfregaço fecal direto. O laboratório relata a presença de algumas bactérias Gram-negativas levemente curvadas, porém em quantidade pequena e com muitas outras morfologias bacterianas também presentes, tornando o resultado inconclusivo."
        ],
        technicalComment: [
          "Conduta Insuficiente: A coloração de Gram de um esfregaço fecal pode, em alguns casos de cólera com alta carga bacteriana, revelar numerosos bacilos Gram-negativos curvos (vibriões). No entanto, este achado não é específico (outros vibriões não coléricos ou bactérias com morfologia semelhante podem estar presentes) e tem baixa sensibilidade, especialmente se a carga bacteriana for menor.",
          "Não é suficiente para confirmar o diagnóstico de cólera nem para identificar outros patógenos importantes. Em fezes diarreicas, a diversidade da microbiota normal e a diluição do material tornam a interpretação do Gram ainda mais difícil.",
          "Para diagnóstico microbiológico adequado de diarreias infecciosas, especialmente com suspeita de patógenos de relevância epidemiológica como V. cholerae, são necessários métodos mais específicos como cultura em meios seletivos e testes de identificação bioquímica e sorológica."
        ],
        nextQuestionId: "q4"
      },
      {
        id: "5A",
        subtitle: "Você optou por campanhas anuais de vacinação em massa contra cólera e ETEC.",
        isIncorrect: true,
        content: [
          "Você recomenda a implementação de campanhas anuais de vacinação em massa contra cólera e ETEC para toda a população. A equipe de saúde pública informa que existem limitações significativas: a vacina contra cólera tem disponibilidade restrita e proteção parcial temporária, enquanto para ETEC não há vacina licenciada para uso populacional amplo no país."
        ],
        technicalComment: [
          "Opção com Limitações: A vacinação é uma ferramenta valiosa de saúde pública. Vacinas orais contra a cólera existem e são recomendadas pela OMS em contextos específicos (surtos, áreas de alta endemicidade, grupos de alto risco), oferecendo proteção por um período limitado.",
          "No entanto, a vacinação em massa anual de toda a população pode não ser a estratégia mais custo-efetiva ou sustentável a longo prazo para o controle endêmico, e a proteção não é de 100% nem permanente.",
          "Para ETEC, as vacinas ainda estão em fase de desenvolvimento e estudos, sem disponibilidade para uso em larga escala.",
          "Embora a imunização seja uma ferramenta complementar valiosa em cenários específicos, sozinha não aborda as causas fundamentais da transmissão de doenças diarreicas de veiculação hídrica, que estão ligadas às condições de saneamento básico."
        ],
        nextQuestionId: "q5"
      },
      {
        id: "5B",
        subtitle: "Você optou pela distribuição profilática em massa de antibióticos.",
        isIncorrect: true,
        content: [
          "Você recomenda a distribuição profilática em massa de antibióticos para comunidades em áreas de risco durante períodos de maior incidência de diarreia. Após alguns meses de implementação desta estratégia, observa-se aumento alarmante de cepas bacterianas resistentes a múltiplos antibióticos na região, tornando o tratamento de infecções comuns cada vez mais difícil e menos eficaz."
        ],
        technicalComment: [
          "Opção Inadequada e Perigosa: Esta é uma medida inadequada e potencialmente perigosa. A profilaxia antibiótica em massa para a população geral não é uma estratégia recomendada para a prevenção de diarreias endêmicas.",
          "Isso levaria a um aumento drástico e rápido da resistência bacteriana aos antimicrobianos, tornando o tratamento de infecções futuras muito mais difícil e caro. Além disso, haveria custos elevados e risco de efeitos colaterais dos medicamentos na população.",
          "Não existe evidência científica de que a distribuição profilática em massa de antibióticos seja efetiva para prevenção de surtos de cólera ou outras diarreias bacterianas em nível populacional.",
          "Esta abordagem está em completa contradição com os esforços globais de uso racional de antimicrobianos e combate à resistência bacteriana, sendo fortemente contraindicada pelas organizações de saúde internacionais, incluindo a OMS."
        ],
        nextQuestionId: "q5"
      },
      {
        id: "5C",
        subtitle: "Você optou por investimento em saneamento básico e educação em saúde.",
        isCorrect: true,
        content: [
          "Você recomenda um programa abrangente e sustentado de investimento em infraestrutura de saneamento básico (água potável e esgotamento sanitário) associado a educação em saúde. Cinco anos após sua implementação na região, observa-se redução de mais de 80% na incidência não apenas de cólera, mas de todas as doenças diarreicas e outras infecções de transmissão fecal-oral, com impacto significativo nos indicadores de mortalidade infantil."
        ],
        technicalComment: [
          "Opção Correta e Mais Impactante: Absolutamente correto! Esta é a medida mais crítica, fundamental e de maior impacto a longo prazo para a prevenção e controle de diarreias infecciosas transmitidas pela via fecal-oral, incluindo cólera e infecções por ETEC.",
          "O acesso universal à água potável de qualidade, a coleta e o tratamento adequados do esgoto sanitário, e a promoção de práticas de higiene pessoal (lavagem das mãos) e alimentar (manejo seguro dos alimentos) interrompem o ciclo de transmissão de praticamente todos os patógenos entéricos e têm impacto duradouro.",
          "Esta abordagem tem forte evidência científica de efetividade, com excelente relação custo-benefício, além de gerar múltiplos benefícios adicionais à saúde e qualidade de vida das populações.",
          "A experiência histórica global mostra que países que investiram consistentemente em saneamento básico conseguiram controlar de forma sustentável doenças como a cólera, mesmo antes da disponibilidade de antibióticos ou vacinas."
        ],
        isFinal: true
      }
    ]
  }
];
