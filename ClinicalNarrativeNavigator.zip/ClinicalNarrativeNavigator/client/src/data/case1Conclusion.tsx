import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const CaseConclusion: React.FC = () => {
  return (
    <Card className="border-primary-200 shadow-md">
      <CardContent className="pt-6">
        <h3 className="text-xl font-bold text-primary-700 mb-4">
          Conclusão do Caso Clínico e Comentários Técnicos Finais:
        </h3>
        
        <div className="prose max-w-none text-neutral-800">
          <p className="mb-3">
            J.S.L., uma criança de 2 anos vivendo em condições de saneamento precário no Nordeste, apresentou um quadro agudo de diarreia aquosa profusa ("água de arroz"), vômitos e desidratação significativa. A principal suspeita clínica, fortemente corroborada pela descrição clássica das fezes, foi cólera, causada por Vibrio cholerae. Uma hipótese diferencial importante para diarreia aquosa nesse contexto é a infecção por Escherichia coli enterotoxigênica (ETEC).
          </p>
          
          <h4 className="font-semibold text-primary-600 mt-4 mb-2">
            Aspectos Bacteriológicos Chave:
          </h4>
          <ul className="list-disc pl-6 space-y-1">
            <li><span className="font-medium">Vibrio cholerae:</span> Bacilo Gram-negativo curvo, móvel, produtor da toxina colérica que leva à hipersecreção de fluidos e eletrólitos. Cresce bem em meio seletivo TCBS (colônias amarelas). A identificação dos sorogrupos O1 ou O139 é crucial para a epidemiologia.</li>
            <li><span className="font-medium">Escherichia coli enterotoxigênica (ETEC):</span> Bacilo Gram-negativo, produtor das toxinas LT e/ou ST. Causa comum de diarreia aquosa. Sua identificação requer detecção das toxinas, não apenas o isolamento de E. coli.</li>
          </ul>
          
          <h4 className="font-semibold text-primary-600 mt-4 mb-2">
            Manejo Clínico:
          </h4>
          <p className="mb-2">
            A prioridade absoluta foi a reidratação vigorosa (oral ou intravenosa), que é a medida salvadora de vidas. Em casos de cólera confirmada ou com alta suspeita e gravidade, a antibioticoterapia (ex: azitromicina para crianças, ou doxiciclina/ciprofloxacina para adultos, conforme sensibilidade local) pode ser adjuvante para reduzir a duração da doença e a excreção do vibrião.
          </p>
          
          <h4 className="font-semibold text-primary-600 mt-4 mb-2">
            Diagnóstico Laboratorial:
          </h4>
          <p className="mb-2">
            A coleta de fezes para cultura em meio TCBS e teste rápido de antígeno para V. cholerae são essenciais para confirmação e vigilância. A coprocultura em meios de rotina pode identificar outros patógenos.
          </p>
          
          <h4 className="font-semibold text-primary-600 mt-4 mb-2">
            Saúde Pública:
          </h4>
          <p className="mb-2">
            A notificação imediata de casos suspeitos de cólera é mandatória para ações de controle de surto. A prevenção a longo prazo depende crucialmente de melhorias no saneamento básico (água potável e esgoto tratado) e educação em saúde sobre higiene.
          </p>
          
          <p className="mt-4">
            Este caso ilustra a importância do raciocínio clínico-epidemiológico na suspeita de doenças infecciosas prevalentes em contextos de vulnerabilidade socioambiental. Destaca também o papel central da bacteriologia no diagnóstico etiológico, orientando o tratamento individual e, fundamentalmente, as ações de saúde pública para prevenção e controle de doenças como a cólera, que ainda representa um desafio em muitas regiões, incluindo áreas do Nordeste brasileiro.
          </p>
        </div>
        
        <div className="mt-6 p-4 bg-primary-50 border-l-4 border-primary-500 rounded-md">
          <p className="text-primary-800 font-medium">
            Idealizado e desenvolvido pelo Prof. Rodrigo Niskier
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default CaseConclusion;