import React, { useState } from "react";
import { Link } from "wouter";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const Header: React.FC = () => {
  const [open, setOpen] = useState(false);

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm py-4">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link href="/">
            <div className="text-xl font-bold text-primary-700 cursor-pointer">
              Casos Clínicos Interativos
              <div className="text-sm font-medium text-primary-600">
                Prof. Rodrigo Niskier
              </div>
            </div>
          </Link>
          
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li>
                <Link href="/">
                  <div className="text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer">
                    Início
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/case/1">
                  <div className="text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer">
                    Caso Clínico 1
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <div className="text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer">
                    Sobre
                  </div>
                </Link>
              </li>
            </ul>
          </nav>
          
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild className="md:hidden">
              <button className="text-neutral-600">
                <Menu size={24} />
              </button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="w-full py-4">
                <nav>
                  <ul className="space-y-4">
                    <li>
                      <div 
                        className="block text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer"
                        onClick={() => {
                          setOpen(false);
                          window.location.href = "/";
                        }}>
                        Início
                      </div>
                    </li>
                    <li>
                      <div 
                        className="block text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer"
                        onClick={() => {
                          setOpen(false);
                          window.location.href = "/case/1";
                        }}>
                        Caso Clínico 1
                      </div>
                    </li>
                    <li>
                      <div 
                        className="block text-neutral-600 hover:text-primary-600 transition-colors cursor-pointer"
                        onClick={() => {
                          setOpen(false);
                          window.location.href = "/about";
                        }}>
                        Sobre
                      </div>
                    </li>
                  </ul>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
